// main.js - Enhanced Mesh Cutting System for Three.js
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ==================== MAIN APPLICATION ====================
class MeshCuttingApp {
    constructor() {
        console.log('Initializing Mesh Cutting App...');
        console.log('THREE.js version:', THREE.REVISION);
        
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        
        this.cutMode = 'instant'; // 'instant' or 'drag'
        this.cutStart = null;
        this.cutEnd = null;
        this.isCutting = false;
        this.cutLine = null;
        
        this.deformableMeshes = [];
        
        this.init();
        this.createScene();
        this.setupEventListeners();
        this.createUI();
        this.animate();
    }
    
    init() {
        console.log('Setting up renderer...');
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.body.appendChild(this.renderer.domElement);
        console.log('Renderer added to DOM');
        
        this.camera.position.set(0, 3, 5);
        this.camera.lookAt(0, 0, 0);
        console.log('Camera positioned');
        
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        console.log('OrbitControls initialized');
        
        this.scene.background = new THREE.Color(0x1a1a2e);
        
        // Create cut line
        const lineMaterial = new THREE.LineBasicMaterial({ color: 0xff0044, linewidth: 2 });
        const lineGeometry = new THREE.BufferGeometry();
        this.cutLine = new THREE.Line(lineGeometry, lineMaterial);
        this.cutLine.visible = false;
        this.scene.add(this.cutLine);
        console.log('Cut line created');
    }
    
    createUI() {
        const uiContainer = document.getElementById('info');
        
        // Add mode selector
        const modeSelector = document.createElement('div');
        modeSelector.style.marginTop = '10px';
        modeSelector.innerHTML = `
            <label style="color: white; margin-right: 10px;">Cut Mode:</label>
            <select id="cutModeSelect" style="padding: 5px; border-radius: 3px;">
                <option value="instant">Instant Cut (Click)</option>
                <option value="drag">Drag Cut</option>
            </select>
        `;
        uiContainer.appendChild(modeSelector);
        
        document.getElementById('cutModeSelect').addEventListener('change', (e) => {
            this.cutMode = e.target.value;
            console.log('Cut mode changed to:', this.cutMode);
        });
        
        // Add reset button
        const resetButton = document.createElement('button');
        resetButton.textContent = 'Reset Scene';
        resetButton.style.marginTop = '10px';
        resetButton.style.padding = '8px 15px';
        resetButton.style.backgroundColor = '#ff0044';
        resetButton.style.color = 'white';
        resetButton.style.border = 'none';
        resetButton.style.borderRadius = '5px';
        resetButton.style.cursor = 'pointer';
        resetButton.style.fontWeight = 'bold';
        resetButton.onclick = () => this.resetScene();
        uiContainer.appendChild(resetButton);
    }
    
    createScene() {
        console.log('Creating scene...');
        
        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);
        
        const dirLight = new THREE.DirectionalLight(0xffffff, 1);
        dirLight.position.set(5, 10, 5);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width = 2048;
        dirLight.shadow.mapSize.height = 2048;
        this.scene.add(dirLight);
        
        // Add point lights for better visualization
        const pointLight1 = new THREE.PointLight(0x00ffff, 0.5);
        pointLight1.position.set(-3, 2, 3);
        this.scene.add(pointLight1);
        
        const pointLight2 = new THREE.PointLight(0xff00ff, 0.5);
        pointLight2.position.set(3, 2, -3);
        this.scene.add(pointLight2);
        
        console.log('Lights added');
        
        // Ground plane
        const groundGeometry = new THREE.PlaneGeometry(20, 20);
        const groundMaterial = new THREE.MeshStandardMaterial({ 
            color: 0x16213e,
            roughness: 0.8,
            metalness: 0.2
        });
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.position.y = -0.5;
        ground.receiveShadow = true;
        this.scene.add(ground);
        console.log('Ground added');
        
        // Create deformable cloth mesh
        this.createDeformableMesh();
        console.log('Scene creation complete');
    }
    
    createDeformableMesh() {
        const width = 3;
        const height = 3;
        const thickness = 0.15;
        const segments = 30;

        // Create a box-like rug using BoxGeometry
        const geometry = new THREE.BoxGeometry(width, thickness, height, segments, 2, segments);

        // Rug material
        const material = new THREE.MeshStandardMaterial({ 
            color: 0x8b5a2b,
            roughness: 1,
            metalness: 0,
            side: THREE.DoubleSide
        });

        const rug = new THREE.Mesh(geometry, material);
        rug.position.set(0, 1.5, 0);
        rug.castShadow = true;
        rug.receiveShadow = true;

        // Make deformable
        const deformable = new DeformableMesh(rug);
        this.deformableMeshes.push(deformable);
        this.scene.add(rug);
        
        console.log('Rug mesh created with', geometry.attributes.position.count, 'vertices');
    }
    
    resetScene() {
        // Remove all deformable meshes
        this.deformableMeshes.forEach(deformable => {
            this.scene.remove(deformable.mesh);
            deformable.mesh.geometry.dispose();
            deformable.mesh.material.dispose();
        });
        this.deformableMeshes = [];
        
        // Create new mesh
        this.createDeformableMesh();
        console.log('Scene reset');
    }
    
    setupEventListeners() {
        window.addEventListener('resize', () => this.onWindowResize());
        window.addEventListener('mousedown', (e) => this.onMouseDown(e));
        window.addEventListener('mousemove', (e) => this.onMouseMove(e));
        window.addEventListener('mouseup', (e) => this.onMouseUp(e));
        window.addEventListener('contextmenu', (e) => e.preventDefault());
    }
    
    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
    
    updateMouse(event) {
        this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    }
    
    onMouseDown(event) {
        this.updateMouse(event);
        this.raycaster.setFromCamera(this.mouse, this.camera);
        
        const meshes = this.deformableMeshes.map(d => d.mesh);
        const intersects = this.raycaster.intersectObjects(meshes);
        
        if (intersects.length > 0) {
            const point = intersects[0].point;
            
            // Left click - cutting
            if (event.button === 0) {
                if (this.cutMode === 'instant') {
                    // Instant cut mode - generate random cut line
                    this.performInstantCut(intersects[0]);
                } else {
                    // Drag mode - start drawing cut line
                    this.isCutting = true;
                    this.cutStart = point.clone();
                    this.cutEnd = point.clone();
                    this.cutLine.visible = true;
                }
                console.log('Cut started at:', point);
            }
            
            // Right click - deform
            if (event.button === 2) {
                const deformable = this.deformableMeshes.find(d => d.mesh === intersects[0].object);
                if (deformable) {
                    const normal = intersects[0].face.normal.clone();
                    normal.transformDirection(deformable.mesh.matrixWorld);
                    deformable.applyForce(point, normal.multiplyScalar(-50));
                }
            }
        }
    }
    
    performInstantCut(intersection) {
        const mesh = intersection.object;
        const point = intersection.point;
        
        // Generate a random cut direction
        const angle = Math.random() * Math.PI * 2;
        const cutLength = 2;
        const direction = new THREE.Vector3(
            Math.cos(angle),
            0,
            Math.sin(angle)
        ).normalize();
        
        this.cutStart = point.clone().add(direction.clone().multiplyScalar(-cutLength));
        this.cutEnd = point.clone().add(direction.clone().multiplyScalar(cutLength));
        
        // Show cut line briefly
        this.cutLine.visible = true;
        const positions = new Float32Array([
            this.cutStart.x, this.cutStart.y, this.cutStart.z,
            this.cutEnd.x, this.cutEnd.y, this.cutEnd.z
        ]);
        this.cutLine.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        
        // Perform cut
        const deformable = this.deformableMeshes.find(d => d.mesh === mesh);
        if (deformable) {
            this.performCut(deformable, this.cutStart, this.cutEnd);
        }
        
        // Hide cut line after a moment
        setTimeout(() => {
            this.cutLine.visible = false;
        }, 300);
    }
    
    onMouseMove(event) {
        this.updateMouse(event);
        
        if (this.isCutting && this.cutMode === 'drag') {
            this.raycaster.setFromCamera(this.mouse, this.camera);
            const meshes = this.deformableMeshes.map(d => d.mesh);
            const intersects = this.raycaster.intersectObjects(meshes);
            
            if (intersects.length > 0) {
                this.cutEnd = intersects[0].point.clone();
                
                // Update cut line visualization
                const positions = new Float32Array([
                    this.cutStart.x, this.cutStart.y, this.cutStart.z,
                    this.cutEnd.x, this.cutEnd.y, this.cutEnd.z
                ]);
                this.cutLine.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            }
        }
    }
    
    onMouseUp(event) {
        if (this.isCutting && event.button === 0 && this.cutMode === 'drag') {
            console.log('Cut ended. From:', this.cutStart, 'To:', this.cutEnd);
            
            this.raycaster.setFromCamera(this.mouse, this.camera);
            const meshes = this.deformableMeshes.map(d => d.mesh);
            const intersects = this.raycaster.intersectObjects(meshes);
            
            if (intersects.length > 0) {
                const targetMesh = intersects[0].object;
                const deformable = this.deformableMeshes.find(d => d.mesh === targetMesh);
                
                if (deformable) {
                    this.performCut(deformable, this.cutStart, this.cutEnd);
                }
            }
            
            this.isCutting = false;
            this.cutLine.visible = false;
            this.cutStart = null;
            this.cutEnd = null;
        }
    }
    
    performCut(deformable, start, end) {
        console.log('Performing cut on mesh...');
        
        const mesh = deformable.mesh;
        const worldToLocal = mesh.matrixWorld.clone().invert();
        
        const localStart = start.clone().applyMatrix4(worldToLocal);
        const localEnd = end.clone().applyMatrix4(worldToLocal);
        
        const cutDirection = new THREE.Vector3().subVectors(localEnd, localStart).normalize();
        const viewDir = new THREE.Vector3().subVectors(this.camera.position, mesh.position).normalize();
        const cutNormal = new THREE.Vector3().crossVectors(cutDirection, viewDir).normalize();
        
        if (cutNormal.length() < 0.01) {
            cutNormal.crossVectors(cutDirection, new THREE.Vector3(0, 1, 0)).normalize();
        }
        
        const cutPlane = new THREE.Plane().setFromNormalAndCoplanarPoint(cutNormal, localStart);
        
        const result = this.cutMeshByPlane(mesh.geometry, cutPlane);
        
        if (result && result.positive && result.negative) {
            console.log('Cut successful! Creating pieces...');
            
            // Remove original mesh
            this.scene.remove(mesh);
            const index = this.deformableMeshes.indexOf(deformable);
            if (index > -1) {
                this.deformableMeshes.splice(index, 1);
            }
            
            // Create two new pieces with separation force
            const separationDir = cutNormal.clone().applyMatrix4(mesh.matrixWorld.clone().setPosition(0, 0, 0));
            this.createMeshPiece(result.positive, mesh, separationDir.multiplyScalar(1.5));
            this.createMeshPiece(result.negative, mesh, separationDir.multiplyScalar(-1.5));
        } else {
            console.warn('Cut failed - mesh may not intersect cut plane');
        }
    }
    
    cutMeshByPlane(geometry, plane) {
        const positions = geometry.attributes.position.array;
        const indices = geometry.index ? geometry.index.array : null;
        
        const positiveSide = { vertices: [], indices: [] };
        const negativeSide = { vertices: [], indices: [] };
        
        const vertexCount = positions.length / 3;
        const vertices = [];
        
        for (let i = 0; i < vertexCount; i++) {
            vertices.push(new THREE.Vector3(
                positions[i * 3],
                positions[i * 3 + 1],
                positions[i * 3 + 2]
            ));
        }
        
        const triangleCount = indices ? indices.length / 3 : vertexCount / 3;
        
        for (let i = 0; i < triangleCount; i++) {
            const i0 = indices ? indices[i * 3] : i * 3;
            const i1 = indices ? indices[i * 3 + 1] : i * 3 + 1;
            const i2 = indices ? indices[i * 3 + 2] : i * 3 + 2;
            
            const v0 = vertices[i0];
            const v1 = vertices[i1];
            const v2 = vertices[i2];
            
            const d0 = plane.distanceToPoint(v0);
            const d1 = plane.distanceToPoint(v1);
            const d2 = plane.distanceToPoint(v2);
            
            const s0 = d0 > 0;
            const s1 = d1 > 0;
            const s2 = d2 > 0;
            
            if (s0 === s1 && s1 === s2) {
                const targetSide = s0 ? positiveSide : negativeSide;
                this.addTriangle(targetSide, v0, v1, v2);
            } else {
                this.splitTriangle(v0, v1, v2, s0, s1, s2, plane, positiveSide, negativeSide);
            }
        }
        
        if (positiveSide.vertices.length === 0 || negativeSide.vertices.length === 0) {
            return null;
        }
        
        return {
            positive: this.createGeometryFromData(positiveSide),
            negative: this.createGeometryFromData(negativeSide)
        };
    }
    
    splitTriangle(v0, v1, v2, s0, s1, s2, plane, posSide, negSide) {
        const verts = [v0, v1, v2];
        const sides = [s0, s1, s2];
        
        const posCount = (s0 ? 1 : 0) + (s1 ? 1 : 0) + (s2 ? 1 : 0);
        
        if (posCount === 1) {
            for (let i = 0; i < 3; i++) {
                if (sides[i]) {
                    const i1 = (i + 1) % 3;
                    const i2 = (i + 2) % 3;
                    
                    const cut1 = this.intersectPlane(plane, verts[i], verts[i1]);
                    const cut2 = this.intersectPlane(plane, verts[i], verts[i2]);
                    
                    this.addTriangle(posSide, verts[i], cut1, cut2);
                    this.addTriangle(negSide, cut1, verts[i1], verts[i2]);
                    this.addTriangle(negSide, cut1, verts[i2], cut2);
                    break;
                }
            }
        } else if (posCount === 2) {
            for (let i = 0; i < 3; i++) {
                if (!sides[i]) {
                    const i1 = (i + 1) % 3;
                    const i2 = (i + 2) % 3;
                    
                    const cut1 = this.intersectPlane(plane, verts[i], verts[i1]);
                    const cut2 = this.intersectPlane(plane, verts[i], verts[i2]);
                    
                    this.addTriangle(negSide, verts[i], cut1, cut2);
                    this.addTriangle(posSide, cut1, verts[i1], verts[i2]);
                    this.addTriangle(posSide, cut1, verts[i2], cut2);
                    break;
                }
            }
        }
    }
    
    intersectPlane(plane, a, b) {
        const direction = new THREE.Vector3().subVectors(b, a).normalize();
        const ray = new THREE.Ray(a, direction);
        const target = new THREE.Vector3();
        return ray.intersectPlane(plane, target) || a.clone();
    }
    
    addTriangle(side, v0, v1, v2) {
        const baseIdx = side.vertices.length;
        side.vertices.push(v0.clone(), v1.clone(), v2.clone());
        side.indices.push(baseIdx, baseIdx + 1, baseIdx + 2);
    }
    
    createGeometryFromData(data) {
        const geometry = new THREE.BufferGeometry();
        
        const positions = new Float32Array(data.vertices.length * 3);
        for (let i = 0; i < data.vertices.length; i++) {
            positions[i * 3] = data.vertices[i].x;
            positions[i * 3 + 1] = data.vertices[i].y;
            positions[i * 3 + 2] = data.vertices[i].z;
        }
        
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setIndex(data.indices);
        geometry.computeVertexNormals();
        
        return geometry;
    }
    
    createMeshPiece(geometry, originalMesh, forceDir) {
        const material = originalMesh.material.clone();
        const mesh = new THREE.Mesh(geometry, material);
        
        mesh.position.copy(originalMesh.position);
        mesh.rotation.copy(originalMesh.rotation);
        mesh.scale.copy(originalMesh.scale);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        
        const deformable = new DeformableMesh(mesh);
        deformable.velocity.copy(forceDir);
        
        this.deformableMeshes.push(deformable);
        this.scene.add(mesh);
        
        console.log('Created mesh piece with', geometry.attributes.position.count, 'vertices');
    }
    
    animate() {
        requestAnimationFrame(() => this.animate());
        
        this.controls.update();
        
        // Update deformable meshes
        this.deformableMeshes.forEach(deformable => deformable.update());
        
        this.renderer.render(this.scene, this.camera);
    }
}

// ==================== DEFORMABLE MESH CLASS ====================
class DeformableMesh {
    constructor(mesh) {
        this.mesh = mesh;
        this.geometry = mesh.geometry;
        
        const positionAttribute = this.geometry.attributes.position;
        this.originalPositions = new Float32Array(positionAttribute.array);
        this.displacedPositions = new Float32Array(positionAttribute.array);
        this.velocities = new Float32Array(positionAttribute.count * 3);
        
        this.springStiffness = 50;
        this.damping = 0.95;
        this.mass = 1;
        this.gravity = new THREE.Vector3(0, 0, 0);
        
        this.velocity = new THREE.Vector3();
    }
    
    applyForce(worldPoint, force) {
        const localPoint = worldPoint.clone();
        localPoint.applyMatrix4(this.mesh.matrixWorld.clone().invert());
        
        const positions = this.geometry.attributes.position;
        const radius = 0.5;
        
        for (let i = 0; i < positions.count; i++) {
            const vx = positions.getX(i);
            const vy = positions.getY(i);
            const vz = positions.getZ(i);
            
            const vertex = new THREE.Vector3(vx, vy, vz);
            const distance = vertex.distanceTo(localPoint);
            
            if (distance < radius) {
                const influence = 1 - (distance / radius);
                const localForce = force.clone();
                localForce.applyMatrix4(this.mesh.matrixWorld.clone().invert().setPosition(0, 0, 0));
                
                this.velocities[i * 3] += localForce.x * influence * 0.1;
                this.velocities[i * 3 + 1] += localForce.y * influence * 0.1;
                this.velocities[i * 3 + 2] += localForce.z * influence * 0.1;
            }
        }
    }
    
    update() {
        const positions = this.geometry.attributes.position;
        const dt = 1 / 60;
        
        // Update mesh position
        this.mesh.position.add(this.velocity.clone().multiplyScalar(dt));
        this.velocity.multiplyScalar(0.95);
        
        // Update vertex deformation
        for (let i = 0; i < positions.count; i++) {
            const ox = this.originalPositions[i * 3];
            const oy = this.originalPositions[i * 3 + 1];
            const oz = this.originalPositions[i * 3 + 2];
            
            const dx = this.displacedPositions[i * 3];
            const dy = this.displacedPositions[i * 3 + 1];
            const dz = this.displacedPositions[i * 3 + 2];
            
            const springForceX = (ox - dx) * this.springStiffness;
            const springForceY = (oy - dy) * this.springStiffness;
            const springForceZ = (oz - dz) * this.springStiffness;
            
            const ax = springForceX / this.mass;
            const ay = springForceY / this.mass;
            const az = springForceZ / this.mass;
            
            this.velocities[i * 3] += ax * dt;
            this.velocities[i * 3 + 1] += ay * dt;
            this.velocities[i * 3 + 2] += az * dt;
            
            this.velocities[i * 3] *= this.damping;
            this.velocities[i * 3 + 1] *= this.damping;
            this.velocities[i * 3 + 2] *= this.damping;
            
            this.displacedPositions[i * 3] += this.velocities[i * 3] * dt;
            this.displacedPositions[i * 3 + 1] += this.velocities[i * 3 + 1] * dt;
            this.displacedPositions[i * 3 + 2] += this.velocities[i * 3 + 2] * dt;
            
            positions.setXYZ(i, 
                this.displacedPositions[i * 3],
                this.displacedPositions[i * 3 + 1],
                this.displacedPositions[i * 3 + 2]
            );
        }
        
        positions.needsUpdate = true;
        this.geometry.computeVertexNormals();
    }
}

// ==================== START APPLICATION ====================
new MeshCuttingApp();